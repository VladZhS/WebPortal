﻿CREATE TABLE [dbo].[ProductCategory]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1, 1), 
    [Category] NVARCHAR(10) NOT NULL
)