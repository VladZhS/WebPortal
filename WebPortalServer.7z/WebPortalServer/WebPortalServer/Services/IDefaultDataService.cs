﻿namespace WebPortalServer.Services
{
    public interface IDefaultDataService
    {
        public void EnsureDefaultData();
    }
}
