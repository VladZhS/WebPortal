﻿namespace WebPortalServer.Controllers
{
    public interface IActionResult<T>
    {
    }
}